import { FastifyPluginAsync } from 'fastify'
import bcrypt from 'bcryptjs'
import { z } from 'zod'
import { prisma } from '../../db/prisma'

const registerSchema = z.object({
  username: z.string().min(3).max(20).regex(/^[a-zA-Z0-9_]+$/),
  email: z.string().email(),
  password: z.string().min(6),
  gameId: z.string().optional()
})

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string()
})

export const authRoutes: FastifyPluginAsync = async (app) => {
  // POST /api/auth/register
  app.post('/register', async (req, reply) => {
    const body = registerSchema.safeParse(req.body)
    if (!body.success) return reply.status(400).send({ error: body.error.flatten() })

    const { username, email, password, gameId } = body.data

    const exists = await prisma.user.findFirst({
      where: { OR: [{ email }, { username }] }
    })
    if (exists) return reply.status(409).send({ error: 'User already exists' })

    const passwordHash = await bcrypt.hash(password, 12)
    const user = await prisma.user.create({
      data: { username, email, passwordHash, gameId },
      select: { id: true, username: true, email: true, elo: true, createdAt: true }
    })

    const token = app.jwt.sign({ id: user.id, username: user.username }, { expiresIn: '7d' })
    return reply.status(201).send({ user, token })
  })

  // POST /api/auth/login
  app.post('/login', async (req, reply) => {
    const body = loginSchema.safeParse(req.body)
    if (!body.success) return reply.status(400).send({ error: body.error.flatten() })

    const { email, password } = body.data

    const user = await prisma.user.findUnique({ where: { email } })
    if (!user) return reply.status(401).send({ error: 'Invalid credentials' })

    const valid = await bcrypt.compare(password, user.passwordHash)
    if (!valid) return reply.status(401).send({ error: 'Invalid credentials' })

    const token = app.jwt.sign({ id: user.id, username: user.username }, { expiresIn: '7d' })
    return {
      user: { id: user.id, username: user.username, email: user.email, elo: user.elo },
      token
    }
  })

  // GET /api/auth/me
  app.get('/me', { preHandler: [(app as any).authenticate] }, async (req) => {
    const { id } = (req as any).user
    const user = await prisma.user.findUnique({
      where: { id },
      select: { id: true, username: true, email: true, gameId: true, elo: true, wins: true, losses: true, points: true, createdAt: true }
    })
    return user
  })
}
